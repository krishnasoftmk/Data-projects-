# Import necessary python library
import gzip
import json

# define Input file
returned_nhtsa_file = "~/Download/nhtsa_file.jsonl.gz"

# Output file name
parsed_nhtsa_file = "~/Download/parsed_nhtsa_file.json"

# Defining variables
parsed_nhtsa_dict = {
            "Sent_VIN": "",
            "Manufacturer_Name": "",
            "Make": "",
            "Model": "",
            "Model_Year": "",
            "Vehicle_Type_ID": "",
            "Body_Class_ID": "",
            "NCSA_Make": "",
            "NCSA_Model": "",
        }


# Parse function to extract necessary data from nhtsa file 1
def parse_nhtsa_file():

    # TODO Read the input gzip file
    pass

    # TODO Process each row of input file to extract necessary data
    pass

    # TODO Write the updated dict parsed_nhtsa_dict to output file
    pass

